#ifndef PINCHECK_VERSION_CHECK_H
#define PINCHECK_VERSION_CHECK_H

#include "common.h"

void check_new_version(bool is_verbose);

#endif
