#ifndef PINCHECK_JUST_RUNNER_H
#define PINCHECK_JUST_RUNNER_H

#include "common.h"

int just_run(const String &run_command, const String &full_name);

#endif