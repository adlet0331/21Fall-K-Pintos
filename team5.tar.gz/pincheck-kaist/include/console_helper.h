#ifndef PINCHECK_CONSOLE_HELPER_H
#define PINCHECK_CONSOLE_HELPER_H

#include <sys/ioctl.h>
#include "common.h"

struct winsize get_winsize();

#endif