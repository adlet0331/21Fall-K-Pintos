#ifndef PINCHECK_GDB_RUNNER_H
#define PINCHECK_GDB_RUNNER_H

#include "common.h"

int gdb_run(const String &server_command);

#endif
